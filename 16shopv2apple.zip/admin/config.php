<?php
$user = "admin";
$pass = "lol";
$dir = "";