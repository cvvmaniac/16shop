1. Set your domain to server.ini (e.g. server_1 = "google.com")
2. Set your email address in "email_result" of api.php
3. Set the directory where 16shop is located to $dir in admin/config.php
4. Finally, set the username and password for authentication in admin/config.php (default: admin:lol)