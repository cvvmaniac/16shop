1. Set your domain to server.ini (e.g. google.com)
2. Set your email address in "email_result" of api.php
3. Finally, set the username and password for authentication in admin/config.php (default: admin:lol)
4. Enjoy