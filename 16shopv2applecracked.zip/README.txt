[ENG]
1. Set your domain to server.ini (e.g. server_1 = "google.com")
2. Set your email address in "email_result" of api.php
3. Set the directory where 16shop is located to $dir in admin/config.php (If it's at the "/", you don't need to change it! e.g. /16shop)
4. Finally, set the username and password for authentication in admin/config.php (default: admin:lol)
[JPN]
1. あなたのドメインをserver.iniに設定します (例: server_1 = "google.com")
2. 受信用のメールアドレスをapi.php内の"email_result"に設定します
3. 16shopを設置したディレクトリをadmin/config.phpの$dir変数に設定します (/以下に置いた場合は変更する必要はありません。 例: /16shop)
4. 最後に、管理画面へのログインのためのユーザ名とパスワードをadmin/config.phpで設定します (デフォルト: admin:lol)