<?php
$user = "admin";
$pass = "lol";